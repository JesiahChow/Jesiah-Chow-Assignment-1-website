# Jesiah-Chow-Assignment-1-website

This is a website on a rock band from Japan
Design Process:

- During the design process, I was thinking of what content do I want to add in and the number of pages I want.
  I went to their offical website for some inspiration and to find out what are their style like. In the process,
  I found its mostly dark and so I chosed dark colours for my style.

- This website is for people from all walks of life. Its aim is to spread the popularity of this band and for people to get to know them especially the vocalist who is Japanese and is fluent in English which is rare for a Japanese band. I wan people to listen to their music as it is one of the very few japanese bands that is able to gain recognition outside of Japan particularly in the west and even won international musical awards.

Features:

- On the tour page. The collapsible buttons allow user to use see where the specific locations are for the tour which the user
  is able to click on them to know more information.

- The social media icons in the footer are linked to the actual band's social media accounts.

- For the rest of the pages, most of the images are clickable and will direct the user to the actual band's website where
  there are additional information to view.

A feature I plan to implement is a form for users to use and pay if they want to buy the band's merchandise which I may not implement if it is too complexed.

There are features left to implement such as the store page which i had not started and to include images of their merchandise
and show its cost

Technologies used:
I used Javascript for one of my pages. I get the element by class, created variables, functions and
a for loop to implemented a collapsible button for the band's tours in the tour page.
This is the website that I had referred from:

- https://www.w3schools.com/howto/howto_js_collapsible.asp

I implemented hover button so that when a user hover his/her cursor on the text a colour will pop out
This is the website that I had referred from :

- https://www.w3schools.com/CSSref/sel_hover.php

Testing:
I have not implemented any testing scenarious to my assignment as I was adding content into my webpages but at the end I plan
to add a form to test my codes.

The website content will be in columns in the mobile view but I yet complete fixing the contents to fit in mobile view.

So far I have not found any bug in visual studio code when coding

References:
The photos and icons in this website were obtained from:

- https://www.listal.com/viewimage/9333894
- https://kprofiles.com/one-ok-rock-members-profile/
- https://icons8.com/icons/set/instagram--white
- http://ar-kaze.blogspot.com/2016/12/download-one-ok-rock-2015-35xxxv-japan-tour-live-concert-saitama-super-arena-blueray-720p. html
- https://icons8.com/icons/set/twitter--white
- https://icons8.com/icons/set/youtube--white

I have received inspiration from this website:

- https://www.oneokrock.com/en/

The information are taken from:

- https://www.oneokrock.com/en/
- https://kprofiles.com/one-ok-rock-members-profile/
- Youtube
- Spotify
